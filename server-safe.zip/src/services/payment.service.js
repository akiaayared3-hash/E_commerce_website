import * as paymentModel from "../models/payment.model.js";
import * as orderModel from "../models/order.model.js"; // assume you have this
import {
  PAYMENT_GATEWAY,
  DEFAULT_CURRENCY,
  generateTxRef,
  initializePayment,
  verifyTransaction,
  verifyWebhookSignature,
} from "../utils/payments.util.js";
import { ApiError } from "../utils/apiError.util.js";
import { pool } from "../config/db.js";

/**
 * Called AFTER the order has been created (status = pending)
 * and stock has already been locked/deducted.
 */
export const startPayment = async ({
  order_id,
  amount,
  currency = DEFAULT_CURRENCY,
  customer, // { email, first_name, last_name, phone_number }
  callback_url,
  return_url,
}) => {
  const tx_ref = generateTxRef();

  // 1. Create the payment record first (status = pending by default)
  const paymentId = await paymentModel.insert({
    order_id,
    tx_ref,
    payment_gateway: PAYMENT_GATEWAY,
    amount,
    currency,
  });

  // 2. Call Chapa
  const { checkout_url } = await initializePayment({
    tx_ref,
    amount,
    currency,
    customer,
    callback_url,
    return_url,
  });

  return {
    payment_id: paymentId,
    tx_ref,
    checkout_url,
  };
};

/**
 * Main webhook handler – must be called with the RAW body.
 * Everything runs inside a single DB transaction.
 */
export const handleWebhook = async (rawBody, headers) => {
  // 1. Signature check
  if (!verifyWebhookSignature(rawBody, headers)) {
    throw new ApiError(401, "Invalid webhook signature");
  }

  let event;
  try {
    event = JSON.parse(rawBody.toString());
  } catch {
    throw new ApiError(400, "Invalid webhook payload");
  }

  const tx_ref = event?.tx_ref || event?.data?.tx_ref;
  if (!tx_ref) {
    throw new ApiError(400, "Missing tx_ref in webhook");
  }

  // 2. Always re-verify with the gateway (never trust the webhook alone)
  const verification = await verifyTransaction(tx_ref);

  return pool.transaction(async (conn) => {
    // 3. Lock the payment row
    const payment = await paymentModel.findByTxRefForUpdate(tx_ref, conn);

    if (!payment) {
      // unknown tx_ref – ignore or log
      return { handled: false, reason: "payment_not_found" };
    }

    // Already processed
    if (payment.status !== "pending") {
      return { handled: true, reason: "already_processed", payment };
    }

    // 4. Decide what to do based on real gateway status
    if (verification.status === "success") {
      // Optional extra safety: amount must match
      if (Number(verification.amount) !== Number(payment.amount)) {
        await paymentModel.markFailed(
          payment.id,
          {
            failure_reason: "Amount mismatch",
            gateway_response: verification.raw,
          },
          conn,
        );
        return { handled: true, reason: "amount_mismatch" };
      }

      const updated = await paymentModel.markCompleted(
        payment.id,
        {
          transaction_id: verification.transaction_id,
          gateway_response: verification.raw,
        },
        conn,
      );

      if (updated) {
        // Update the order inside the same transaction
        await orderModel.markAsPaid(payment.order_id, conn);
      }

      return { handled: true, reason: "completed", payment };
    }

    if (verification.status === "failed") {
      await paymentModel.markFailed(
        payment.id,
        {
          failure_reason: "Gateway reported failed",
          gateway_response: verification.raw,
        },
        conn,
      );
      return { handled: true, reason: "failed", payment };
    }

    // still pending → do nothing
    return { handled: true, reason: "still_pending", payment };
  });
};

/**
 * Frontend / mobile can call this to check the latest status
 * (useful when user returns from the payment page).
 */
export const getPaymentStatus = async (tx_ref) => {
  const payment = await paymentModel.findByTxRef(tx_ref);
  if (!payment) throw new ApiError(404, "Payment not found");

  // Optional: re-verify if still pending (helps with delayed webhooks)
  if (payment.status === "pending") {
    const verification = await verifyTransaction(tx_ref);

    if (verification.status === "success") {
      // process it the same way the webhook does
      await handleWebhookFromVerification(payment, verification);
      return paymentModel.findByTxRef(tx_ref); // return fresh data
    }
  }

  return payment;
};

// helper used by getPaymentStatus
async function handleWebhookFromVerification(payment, verification) {
  return pool.transaction(async (conn) => {
    const locked = await paymentModel.findByTxRefForUpdate(
      payment.tx_ref,
      conn,
    );
    if (!locked || locked.status !== "pending") return;

    if (verification.status === "success") {
      const ok = await paymentModel.markCompleted(
        locked.id,
        {
          transaction_id: verification.transaction_id,
          gateway_response: verification.raw,
        },
        conn,
      );
      if (ok) await orderModel.markAsPaid(locked.order_id, conn);
    } else if (verification.status === "failed") {
      await paymentModel.markFailed(
        locked.id,
        {
          failure_reason: "Gateway reported failed",
          gateway_response: verification.raw,
        },
        conn,
      );
    }
  });
}

/**
 * Admin: list payments with pagination
 */
export const listPayments = async ({ status, limit = 20, offset = 0 }) => {
  const [items, total] = await Promise.all([
    paymentModel.findAll({ status, limit, offset }),
    paymentModel.countAll({ status }),
  ]);
  return { items, total, limit, offset };
};
