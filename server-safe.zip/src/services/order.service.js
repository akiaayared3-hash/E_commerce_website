import { pool } from "../config/db.js";
import { ApiError } from "../utils/apiError.util.js";
import * as orderModel from "../models/order.model.js";
import * as addressModel from "../models/address.model.js"; // or delivery.model
import * as inventoryModel from "../models/inventory.model.js";
import * as cartModel from "../models/cart.model.js";
import * as userModel from "../models/user.model.js";
import * as paymentService from "./payment.service.js"; // optional direct call

// ---------- constants ----------

const ORDER_STATUSES = [
  "pending",
  "paid",
  "processing",
  "shipped",
  "delivered",
  "cancelled",
];

const ALLOWED_TRANSITIONS = {
  pending: ["paid", "cancelled"],
  paid: ["processing", "cancelled"],
  processing: ["shipped", "cancelled"],
  shipped: ["delivered"],
  delivered: [],
  cancelled: [],
};

const CUSTOMER_CANCELLABLE = ["pending"];

// ---------- helpers ----------

const withTransaction = async (fn) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
};

const assertId = (value, label = "id") => {
  if (!Number.isInteger(Number(value)) || Number(value) < 1) {
    throw new ApiError(400, `A valid ${label} is required`);
  }
};

const parsePaging = ({ page = 1, limit = 10 } = {}) => {
  const p = Math.max(Number(page) || 1, 1);
  const l = Math.min(Math.max(Number(limit) || 10, 1), 50);
  return { page: p, limit: l, offset: (p - 1) * l };
};

const buildPagination = (page, limit, total) => ({
  page,
  limit,
  total,
  totalPages: Math.ceil(total / limit) || 0,
});

// ---------- core: create order from cart ----------

/**
 * Professional checkout flow:
 * 1. Validate address belongs to user
 * 2. Load existing cart + items
 * 3. Lock stock rows (FOR UPDATE)
 * 4. Re-check availability & active status
 * 5. Calculate total from current prices
 * 6. Create order + order_items (with address snapshot)
 * 7. Deduct stock
 * 8. Clear cart
 * 9. Return order (controller can then start payment)
 */
export const createOrderFromCart = async (user_id, shipping_address_id) => {
  assertId(user_id, "user id");
  assertId(shipping_address_id, "shipping address id");

  // Address must belong to the user
  const address = await addressModel.findByIdAndUser(
    shipping_address_id,
    user_id,
  );
  if (!address) {
    throw new ApiError(404, "Shipping address not found");
  }

  const orderId = await withTransaction(async (conn) => {
    // 1. Get existing cart (do NOT create a new one)
    const cart = await cartModel.findByUser(user_id, conn);
    if (!cart) throw new ApiError(400, "Your cart is empty");

    const items = await cartModel.listItems(cart.id, conn);
    if (!items.length) throw new ApiError(400, "Your cart is empty");

    // 2. Lock stock rows in consistent order (prevents deadlocks)
    const variantIds = [...new Set(items.map((i) => i.variant_id))].sort(
      (a, b) => a - b,
    );

    const lockedRows = await inventoryModel.lockStockForVariants(
      variantIds,
      conn,
    );

    const stockMap = new Map(
      lockedRows.map((r) => [r.product_variant_id, r.stock_quantity]),
    );

    // 3. Final validation against locked stock
    const problems = [];
    for (const item of items) {
      const label = `${item.product_name} (${item.variant_name})`;
      const available = stockMap.get(item.variant_id) ?? 0;

      if (!item.product_active || !item.variant_active) {
        problems.push(`${label}: no longer available`);
      } else if (item.quantity > available) {
        problems.push(
          available === 0
            ? `${label}: out of stock`
            : `${label}: only ${available} left`,
        );
      }
    }

    if (problems.length) {
      throw new ApiError(409, `Cannot place order. ${problems.join("; ")}`);
    }

    // 4. Calculate total from CURRENT prices (freeze them)
    let totalAmount = 0;
    const orderLines = items.map((item) => {
      const lineTotal = Number(item.price) * item.quantity;
      totalAmount += lineTotal;
      return {
        product_variant_id: item.variant_id,
        quantity: item.quantity,
        unit_price: Number(item.price),
      };
    });

    if (totalAmount <= 0) {
      throw new ApiError(400, "Order total must be greater than zero");
    }

    // 5. Create order with address SNAPSHOT
    const newOrderId = await orderModel.insert(
      {
        user_id,
        shipping_address_id,
        // snapshot – critical
        shipping_full_name: address.full_name,
        shipping_phone: address.phone,
        shipping_region: address.region,
        shipping_city: address.city,
        shipping_sub_city: address.sub_city ?? null,
        shipping_woreda: address.woreda ?? null,
        shipping_street: address.street ?? null,
        shipping_landmark: address.landmark ?? null,
        total_amount: totalAmount,
        order_status: "pending",
      },
      conn,
    );

    // 6. Insert order items (price frozen)
    await orderModel.insertItems(
      orderLines.map((line) => ({
        order_id: newOrderId,
        ...line,
      })),
      conn,
    );

    // 7. Deduct stock (still under the same locks)
    await inventoryModel.deductStockBulk(
      orderLines.map((l) => ({
        product_variant_id: l.product_variant_id,
        quantity: l.quantity,
      })),
      conn,
    );

    // 8. Clear cart
    await cartModel.clear(cart.id, conn);

    return newOrderId;
  });

  // Return full order after commit
  return getMyOrderById(user_id, orderId);
};

/**
 * Optional helper: create order + immediately start payment
 * (useful if you want one endpoint that returns checkout_url)
 */
export const createOrderAndStartPayment = async (
  user_id,
  shipping_address_id,
  { callback_url, return_url },
) => {
  const order = await createOrderFromCart(user_id, shipping_address_id);

  const user = await userModel.findById(user_id);

  const payment = await paymentService.startPayment({
    order_id: order.id,
    amount: order.total_amount,
    currency: "ETB",
    customer: {
      email: user.email,
      first_name: user.first_name,
      last_name: user.last_name,
      phone_number: user.phone_number,
    },
    callback_url,
    return_url,
  });

  return {
    order,
    payment: {
      tx_ref: payment.tx_ref,
      checkout_url: payment.checkout_url,
    },
  };
};

// ---------- customer reads & cancel ----------

export const getMyOrderById = async (user_id, order_id) => {
  assertId(order_id, "order id");

  const order = await orderModel.findByIdAndUser(order_id, user_id);
  if (!order) throw new ApiError(404, "Order not found");

  const items = await orderModel.listByOrderId(order_id);
  return { ...order, items };
};

export const getMyOrders = async (user_id, paging = {}) => {
  const { page, limit, offset } = parsePaging(paging);

  const [orders, total] = await Promise.all([
    orderModel.findByUser(user_id, { limit, offset }),
    orderModel.countByUser(user_id),
  ]);

  return {
    orders,
    pagination: buildPagination(page, limit, total),
  };
};

export const cancelMyOrder = async (user_id, order_id) => {
  assertId(order_id, "order id");

  await withTransaction(async (conn) => {
    const order = await orderModel.findByIdAndUser(order_id, user_id, conn);
    if (!order) throw new ApiError(404, "Order not found");

    if (!CUSTOMER_CANCELLABLE.includes(order.order_status)) {
      throw new ApiError(
        409,
        `An order that is "${order.order_status}" cannot be cancelled`,
      );
    }

    const moved = await orderModel.transitionStatus(
      order_id,
      order.order_status,
      "cancelled",
      conn,
    );
    if (!moved) {
      throw new ApiError(409, "Order status changed, please try again");
    }

    // Restock
    const items = await orderModel.listByOrderId(order_id, conn);
    await inventoryModel.restoreStockBulk(
      items.map((i) => ({
        product_variant_id: i.product_variant_id,
        quantity: i.quantity,
      })),
      conn,
    );
  });

  return getMyOrderById(user_id, order_id);
};

// ---------- admin ----------

export const getAllOrders = async ({ status, page, limit } = {}) => {
  if (status && !ORDER_STATUSES.includes(status)) {
    throw new ApiError(
      400,
      `status must be one of: ${ORDER_STATUSES.join(", ")}`,
    );
  }

  const paging = parsePaging({ page, limit });

  const [orders, total] = await Promise.all([
    orderModel.findAll({
      status: status || null,
      limit: paging.limit,
      offset: paging.offset,
    }),
    orderModel.countAll({ status: status || null }),
  ]);

  return {
    orders,
    pagination: buildPagination(paging.page, paging.limit, total),
  };
};

export const getOrderByIdAdmin = async (order_id) => {
  assertId(order_id, "order id");

  const order = await orderModel.findById(order_id);
  if (!order) throw new ApiError(404, "Order not found");

  const items = await orderModel.listByOrderId(order_id);
  return { ...order, items };
};

export const updateOrderStatus = async (order_id, new_status) => {
  assertId(order_id, "order id");

  if (!ORDER_STATUSES.includes(new_status)) {
    throw new ApiError(
      400,
      `status must be one of: ${ORDER_STATUSES.join(", ")}`,
    );
  }

  await withTransaction(async (conn) => {
    const order = await orderModel.findById(order_id, conn);
    if (!order) throw new ApiError(404, "Order not found");

    const allowed = ALLOWED_TRANSITIONS[order.order_status] || [];
    if (!allowed.includes(new_status)) {
      throw new ApiError(
        409,
        `Cannot change order from "${order.order_status}" to "${new_status}"`,
      );
    }

    if (new_status === "cancelled") {
      const moved = await orderModel.transitionStatus(
        order_id,
        order.order_status,
        "cancelled",
        conn,
      );
      if (!moved) throw new ApiError(409, "Order status changed");

      const items = await orderModel.listByOrderId(order_id, conn);
      await inventoryModel.restoreStockBulk(
        items.map((i) => ({
          product_variant_id: i.product_variant_id,
          quantity: i.quantity,
        })),
        conn,
      );
      return;
    }

    const moved = await orderModel.transitionStatus(
      order_id,
      order.order_status,
      new_status,
      conn,
    );
    if (!moved) {
      throw new ApiError(409, "Order status changed, please try again");
    }
  });

  return getOrderByIdAdmin(order_id);
};

/**
 * Called by payment webhook when payment succeeds
 */
export const markOrderAsPaid = async (order_id, conn = null) => {
  const run = async (connection) => {
    const order = await orderModel.findById(order_id, connection);
    if (!order) throw new ApiError(404, "Order not found");

    if (order.order_status === "paid") return order; // already paid
    if (order.order_status !== "pending") {
      throw new ApiError(
        409,
        `Cannot mark order as paid from status "${order.order_status}"`,
      );
    }

    const moved = await orderModel.transitionStatus(
      order_id,
      "pending",
      "paid",
      connection,
    );
    if (!moved) throw new ApiError(409, "Order status changed");

    return orderModel.findById(order_id, connection);
  };

  if (conn) return run(conn);
  return withTransaction(run);
};
