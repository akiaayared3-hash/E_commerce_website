import { Router } from "express";
import {
  protect,
  restrictTo,
} from "../middlewares/authenthicate.middlewares.js";
import {
  createOrderHandler,
  getMyOrdersHandler,
  getMyOrderHandler,
  cancelMyOrderHandler,
  getAllOrdersHandler,
  getOrderAdminHandler,
  updateOrderStatusHandler,
} from "../controllers/order.controller.js";

const router = Router();

// every order route needs a logged-in user
router.use(protect);

// admin routes first, so "admin" is never read as an order id
router.get("/admin/all", restrictTo("admin"), getAllOrdersHandler);
router.get("/admin/:orderId", restrictTo("admin"), getOrderAdminHandler);
router.patch(
  "/admin/:orderId/status",
  restrictTo("admin"),
  updateOrderStatusHandler,
);

// customer routes
router.post("/", createOrderHandler);
router.get("/", getMyOrdersHandler);
router.get("/:orderId", getMyOrderHandler);
router.patch("/:orderId/cancel", cancelMyOrderHandler);

export default router;
