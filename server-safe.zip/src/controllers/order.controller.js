// services/order.service.js
import { pool } from "../config/db.js";
import { ApiError } from "../utils/apiError.util.js";
import * as orderModel from "../models/order.model.js";
import * as addressModel from "../models/address.model.js";
import * as inventoryModel from "../models/inventory.model.js";
import * as cartModel from "../models/cart.model.js";
import * as userModel from "../models/user.model.js";
import * as paymentService from "./payment.service.js";

// ---------- constants ----------

export const ORDER_STATUS = {
  PENDING: "pending",
  PAID: "paid",
  PROCESSING: "processing",
  SHIPPED: "shipped",
  DELIVERED: "delivered",
  CANCELLED: "cancelled",
};

export const ORDER_STATUSES = Object.values(ORDER_STATUS);

const ALLOWED_TRANSITIONS = {
  [ORDER_STATUS.PENDING]: [ORDER_STATUS.PAID, ORDER_STATUS.CANCELLED],
  [ORDER_STATUS.PAID]: [ORDER_STATUS.PROCESSING, ORDER_STATUS.CANCELLED],
  [ORDER_STATUS.PROCESSING]: [ORDER_STATUS.SHIPPED, ORDER_STATUS.CANCELLED],
  [ORDER_STATUS.SHIPPED]: [ORDER_STATUS.DELIVERED],
  [ORDER_STATUS.DELIVERED]: [],
  [ORDER_STATUS.CANCELLED]: [],
};

const CUSTOMER_CANCELLABLE = [ORDER_STATUS.PENDING];

// ---------- helpers ----------

const withTransaction = async (fn) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
};

const assertId = (value, label = "id") => {
  if (!Number.isInteger(Number(value)) || Number(value) < 1) {
    throw new ApiError(400, `A valid ${label} is required`);
  }
};

const parsePaging = ({ page = 1, limit = 10 } = {}) => {
  const p = Math.max(Number(page) || 1, 1);
  const l = Math.min(Math.max(Number(limit) || 10, 1), 50);
  return { page: p, limit: l, offset: (p - 1) * l };
};

const buildPagination = (page, limit, total) => ({
  page,
  limit,
  total,
  totalPages: Math.ceil(total / limit) || 0,
});

// ---------- core: create order from cart ----------

/**
 * Professional checkout flow
 * 1. Validate address belongs to user (inside TX)
 * 2. Load cart + items
 * 3. Lock stock rows in sorted order (FOR UPDATE)
 * 4. Re-check active status + quantity under lock
 * 5. Freeze current prices & calculate total
 * 6. Create order + order_items with address snapshot
 * 7. Deduct stock
 * 8. Clear cart
 * 9. Return hydrated order
 */
export const createOrderFromCart = async (userId, shippingAddressId) => {
  assertId(userId, "user id");
  assertId(shippingAddressId, "shipping address id");

  const orderId = await withTransaction(async (conn) => {
    // 1. Address ownership check inside transaction
    const address = await addressModel.findByIdAndUser(
      shippingAddressId,
      userId,
      conn,
    );
    if (!address) {
      throw new ApiError(404, "Shipping address not found");
    }

    // 2. Load existing cart (never create a new one here)
    const cart = await cartModel.findByUser(userId, conn);
    if (!cart) throw new ApiError(400, "Your cart is empty");

    const items = await cartModel.listItems(cart.id, conn);
    if (!items.length) throw new ApiError(400, "Your cart is empty");

    // 3. Lock stock in deterministic order → prevents deadlocks
    const variantIds = [...new Set(items.map((i) => i.variant_id))].sort(
      (a, b) => a - b,
    );

    const lockedRows = await inventoryModel.lockStockForVariants(
      variantIds,
      conn,
    );

    const stockMap = new Map(
      lockedRows.map((r) => [r.product_variant_id, r.stock_quantity]),
    );

    // 4. Final validation under lock
    const problems = [];
    for (const item of items) {
      const label = `${item.product_name} (${item.variant_name})`;
      const available = stockMap.get(item.variant_id) ?? 0;

      if (!item.product_active || !item.variant_active) {
        problems.push(`${label}: no longer available`);
      } else if (item.quantity > available) {
        problems.push(
          available === 0
            ? `${label}: out of stock`
            : `${label}: only ${available} left`,
        );
      }
    }

    if (problems.length) {
      throw new ApiError(409, `Cannot place order. ${problems.join("; ")}`);
    }

    // 5. Freeze prices & calculate total
    let totalAmount = 0;
    const orderLines = items.map((item) => {
      const unitPrice = Number(item.price);
      totalAmount += unitPrice * item.quantity;

      return {
        product_variant_id: item.variant_id,
        quantity: item.quantity,
        unit_price: unitPrice,
      };
    });

    if (totalAmount <= 0) {
      throw new ApiError(400, "Order total must be greater than zero");
    }

    // 6. Create order + full address snapshot
    const newOrderId = await orderModel.insert(
      {
        user_id: userId,
        shipping_address_id: shippingAddressId,
        shipping_full_name: address.full_name,
        shipping_phone: address.phone,
        shipping_region: address.region,
        shipping_city: address.city,
        shipping_sub_city: address.sub_city ?? null,
        shipping_woreda: address.woreda ?? null,
        shipping_street: address.street ?? null,
        shipping_landmark: address.landmark ?? null,
        total_amount: totalAmount,
        order_status: ORDER_STATUS.PENDING,
      },
      conn,
    );

    // 7. Insert order items (prices frozen)
    await orderModel.insertItems(
      orderLines.map((line) => ({
        order_id: newOrderId,
        ...line,
      })),
      conn,
    );

    // 8. Deduct stock (still under the same locks)
    await inventoryModel.deductStockBulk(
      orderLines.map((l) => ({
        product_variant_id: l.product_variant_id,
        quantity: l.quantity,
      })),
      conn,
    );

    // 9. Clear cart
    await cartModel.clear(cart.id, conn);

    return newOrderId;
  });

  return getMyOrderById(userId, orderId);
};

/**
 * Optional: create order + immediately start payment
 */
export const createOrderAndStartPayment = async (
  userId,
  shippingAddressId,
  { callback_url, return_url },
) => {
  const order = await createOrderFromCart(userId, shippingAddressId);
  const user = await userModel.findById(userId);

  const payment = await paymentService.startPayment({
    order_id: order.id,
    amount: order.total_amount,
    currency: "ETB",
    customer: {
      email: user.email,
      first_name: user.first_name,
      last_name: user.last_name,
      phone_number: user.phone_number,
    },
    callback_url,
    return_url,
  });

  return {
    order,
    payment: {
      tx_ref: payment.tx_ref,
      checkout_url: payment.checkout_url,
    },
  };
};

// ---------- customer reads & cancel ----------

export const getMyOrderById = async (userId, orderId) => {
  assertId(orderId, "order id");

  const order = await orderModel.findByIdAndUser(orderId, userId);
  if (!order) throw new ApiError(404, "Order not found");

  const items = await orderModel.listByOrderId(orderId);
  return { ...order, items };
};

export const getMyOrders = async (userId, paging = {}) => {
  const { page, limit, offset } = parsePaging(paging);

  const [orders, total] = await Promise.all([
    orderModel.findByUser(userId, { limit, offset }),
    orderModel.countByUser(userId),
  ]);

  return {
    orders,
    pagination: buildPagination(page, limit, total),
  };
};

export const cancelMyOrder = async (userId, orderId) => {
  assertId(orderId, "order id");

  await withTransaction(async (conn) => {
    const order = await orderModel.findByIdAndUser(orderId, userId, conn);
    if (!order) throw new ApiError(404, "Order not found");

    if (!CUSTOMER_CANCELLABLE.includes(order.order_status)) {
      throw new ApiError(
        409,
        `An order that is "${order.order_status}" cannot be cancelled`,
      );
    }

    const moved = await orderModel.transitionStatus(
      orderId,
      order.order_status,
      ORDER_STATUS.CANCELLED,
      conn,
    );
    if (!moved) {
      throw new ApiError(409, "Order status changed, please try again");
    }

    // Restock
    const items = await orderModel.listByOrderId(orderId, conn);
    await inventoryModel.restoreStockBulk(
      items.map((i) => ({
        product_variant_id: i.product_variant_id,
        quantity: i.quantity,
      })),
      conn,
    );
  });

  return getMyOrderById(userId, orderId);
};

// ---------- admin ----------

export const getAllOrders = async ({ status, page, limit } = {}) => {
  if (status && !ORDER_STATUSES.includes(status)) {
    throw new ApiError(
      400,
      `status must be one of: ${ORDER_STATUSES.join(", ")}`,
    );
  }

  const paging = parsePaging({ page, limit });

  const [orders, total] = await Promise.all([
    orderModel.findAll({
      status: status || null,
      limit: paging.limit,
      offset: paging.offset,
    }),
    orderModel.countAll({ status: status || null }),
  ]);

  return {
    orders,
    pagination: buildPagination(paging.page, paging.limit, total),
  };
};

export const getOrderByIdAdmin = async (orderId) => {
  assertId(orderId, "order id");

  const order = await orderModel.findById(orderId);
  if (!order) throw new ApiError(404, "Order not found");

  const items = await orderModel.listByOrderId(orderId);
  return { ...order, items };
};

export const updateOrderStatus = async (orderId, newStatus) => {
  assertId(orderId, "order id");

  if (!ORDER_STATUSES.includes(newStatus)) {
    throw new ApiError(
      400,
      `status must be one of: ${ORDER_STATUSES.join(", ")}`,
    );
  }

  await withTransaction(async (conn) => {
    const order = await orderModel.findById(orderId, conn);
    if (!order) throw new ApiError(404, "Order not found");

    const allowed = ALLOWED_TRANSITIONS[order.order_status] || [];
    if (!allowed.includes(newStatus)) {
      throw new ApiError(
        409,
        `Cannot change order from "${order.order_status}" to "${newStatus}"`,
      );
    }

    const moved = await orderModel.transitionStatus(
      orderId,
      order.order_status,
      newStatus,
      conn,
    );
    if (!moved) {
      throw new ApiError(409, "Order status changed, please try again");
    }

    // Restock only when cancelling
    if (newStatus === ORDER_STATUS.CANCELLED) {
      const items = await orderModel.listByOrderId(orderId, conn);
      await inventoryModel.restoreStockBulk(
        items.map((i) => ({
          product_variant_id: i.product_variant_id,
          quantity: i.quantity,
        })),
        conn,
      );
    }
  });

  return getOrderByIdAdmin(orderId);
};

/**
 * Called by payment webhook when payment succeeds.
 * Idempotent.
 */
export const markOrderAsPaid = async (orderId, conn = null) => {
  const run = async (connection) => {
    const order = await orderModel.findById(orderId, connection);
    if (!order) throw new ApiError(404, "Order not found");

    if (order.order_status === ORDER_STATUS.PAID) return order; // already paid
    if (order.order_status !== ORDER_STATUS.PENDING) {
      throw new ApiError(
        409,
        `Cannot mark order as paid from status "${order.order_status}"`,
      );
    }

    const moved = await orderModel.transitionStatus(
      orderId,
      ORDER_STATUS.PENDING,
      ORDER_STATUS.PAID,
      connection,
    );
    if (!moved) throw new ApiError(409, "Order status changed");

    return orderModel.findById(orderId, connection);
  };

  if (conn) return run(conn);
  return withTransaction(run);
};
