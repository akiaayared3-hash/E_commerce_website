import { pool } from "../config/db.js";

// Columns that are safe to show a customer (no raw gateway response)
const PAYMENT_COLUMNS = `id, order_id, tx_ref, payment_gateway, transaction_id,
  amount, currency, status, failure_reason, paid_at, created_at, updated_at`;

// Admin detail also includes the raw gateway response
const ADMIN_COLUMNS = `${PAYMENT_COLUMNS}, gateway_response`;

// ---------- create ----------

// status is not passed: the column default is 'pending'
export const insert = async (
  { order_id, tx_ref, payment_gateway, amount, currency = "ETB" },
  db = pool,
) => {
  const [result] = await db.query(
    `INSERT INTO payments (order_id, tx_ref, payment_gateway, amount, currency)
     VALUES (?, ?, ?, ?, ?)`,
    [order_id, tx_ref, payment_gateway, amount, currency],
  );
  return result.insertId;
};

// ---------- read ----------

export const findByTxRef = async (tx_ref, db = pool) => {
  const [rows] = await db.query(
    `SELECT ${PAYMENT_COLUMNS} FROM payments WHERE tx_ref = ?`,
    [tx_ref],
  );
  return rows[0] ?? null;
};

// Locks the payment row. Call it ONLY with the transaction connection,
// otherwise the lock is released immediately and protects nothing.
export const findByTxRefForUpdate = async (tx_ref, db = pool) => {
  const [rows] = await db.query(
    `SELECT ${PAYMENT_COLUMNS} FROM payments WHERE tx_ref = ? FOR UPDATE`,
    [tx_ref],
  );
  return rows[0] ?? null;
};

// admin detail (includes gateway_response)
export const findById = async (id, db = pool) => {
  const [rows] = await db.query(
    `SELECT ${ADMIN_COLUMNS} FROM payments WHERE id = ?`,
    [id],
  );
  return rows[0] ?? null;
};

export const findLatestByOrder = async (order_id, db = pool) => {
  const [rows] = await db.query(
    `SELECT ${PAYMENT_COLUMNS}
     FROM payments
     WHERE order_id = ?
     ORDER BY created_at DESC, id DESC
     LIMIT 1`,
    [order_id],
  );
  return rows[0] ?? null;
};

export const findCompletedByOrder = async (order_id, db = pool) => {
  const [rows] = await db.query(
    `SELECT ${PAYMENT_COLUMNS}
     FROM payments
     WHERE order_id = ? AND status = 'completed'
     LIMIT 1`,
    [order_id],
  );
  return rows[0] ?? null;
};

// all attempts for one order (customer-safe columns)
export const listByOrder = async (order_id, db = pool) => {
  const [rows] = await db.query(
    `SELECT ${PAYMENT_COLUMNS}
     FROM payments
     WHERE order_id = ?
     ORDER BY created_at DESC, id DESC`,
    [order_id],
  );
  return rows;
};

// ---------- status changes (every one is conditional and returns true/false) ----------

// pending -> completed. A second completed payment for the same order is refused by the
// unique index (uq_one_completed_per_order) with a duplicate-entry error: catch it in the service.
export const markCompleted = async (
  id,
  { transaction_id = null, gateway_response = null },
  db = pool,
) => {
  const [result] = await db.query(
    `UPDATE payments
     SET status = 'completed',
         transaction_id = ?,
         gateway_response = ?,
         paid_at = NOW()
     WHERE id = ? AND status = 'pending'`,
    [
      transaction_id,
      gateway_response ? JSON.stringify(gateway_response) : null,
      id,
    ],
  );
  return result.affectedRows > 0;
};

// pending -> failed
export const markFailed = async (
  id,
  { failure_reason = null, gateway_response = null },
  db = pool,
) => {
  const [result] = await db.query(
    `UPDATE payments
     SET status = 'failed',
         failure_reason = ?,
         gateway_response = ?
     WHERE id = ? AND status = 'pending'`,
    [
      failure_reason ? String(failure_reason).slice(0, 255) : null,
      gateway_response ? JSON.stringify(gateway_response) : null,
      id,
    ],
  );
  return result.affectedRows > 0;
};

// pending -> cancelled or expired, for ALL pending attempts of one order.
// Returns how many attempts were closed.
export const closePendingForOrder = async (order_id, status, db = pool) => {
  if (!["cancelled", "expired"].includes(status)) {
    throw new Error("status must be 'cancelled' or 'expired'");
  }

  const [result] = await db.query(
    `UPDATE payments
     SET status = ?
     WHERE order_id = ? AND status = 'pending'`,
    [status, order_id],
  );
  return result.affectedRows;
};

// completed -> refunded
export const markRefunded = async (id, db = pool) => {
  const [result] = await db.query(
    `UPDATE payments
     SET status = 'refunded'
     WHERE id = ? AND status = 'completed'`,
    [id],
  );
  return result.affectedRows > 0;
};

// ---------- admin list ----------

export const findAll = async (
  { status = null, limit = 10, offset = 0 } = {},
  db = pool,
) => {
  const where = status ? `WHERE status = ?` : ``;
  const params = status ? [status, limit, offset] : [limit, offset];

  const [rows] = await db.query(
    `SELECT ${PAYMENT_COLUMNS}
     FROM payments
     ${where}
     ORDER BY created_at DESC, id DESC
     LIMIT ? OFFSET ?`,
    params,
  );
  return rows;
};

export const countAll = async ({ status = null } = {}, db = pool) => {
  const where = status ? `WHERE status = ?` : ``;

  const [rows] = await db.query(
    `SELECT COUNT(*) AS total FROM payments ${where}`,
    status ? [status] : [],
  );
  return rows[0].total;
};
